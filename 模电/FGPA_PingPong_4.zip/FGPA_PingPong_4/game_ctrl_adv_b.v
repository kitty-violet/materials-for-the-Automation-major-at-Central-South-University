module game_ctrl_adv_b (
    input  wire clk_scan,  
    input  wire rst_n,     
    input  wire p1_pulse,  
    input  wire p2_pulse,  
    output reg  [7:0] led, 
    output reg  beep,      
    output reg  add_p1,    
    output reg  add_p2     
);

    parameter S_IDLE   = 3'd0; 
    parameter S_MOVE_R = 3'd1; 
    parameter S_MOVE_L = 3'd2; 
    parameter S_MISS   = 3'd3; 

    reg [2:0] state;
    reg [7:0] speed_cnt; 
    
    // --- ���������ģ���ɱ���桿 ---
    reg smash; // ��ɱ��־λ��1����������ɱ��0������ͨ����
    wire [7:0] current_speed; 
    
    // �ٶȶ�·ѡ��������� smash Ϊ 1���ȴ�ʱ���� 20���ɵü��죩����ͨ�� 50
    assign current_speed = (smash == 1'b1) ? 8'd50 : 8'd100;
    // -----------------------------

    always @(posedge clk_scan or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_IDLE;
            led <= 8'b0000_0000;
            beep <= 0;
            add_p1 <= 0;
            add_p2 <= 0;
            speed_cnt <= 0;
            smash <= 0; 
        end else begin
            add_p1 <= 0; add_p2 <= 0; 

            case (state)
                S_IDLE: begin
                    beep <= 0;
                    smash <= 0; // ���·���ʱ����ɱ��־����
                    if (p1_pulse) begin
                        led <= 8'b1000_0000; state <= S_MOVE_R; speed_cnt <= 0;
                    end else if (p2_pulse) begin
                        led <= 8'b0000_0001; state <= S_MOVE_L; speed_cnt <= 0;
                    end else begin
                        led <= 8'b1000_0001; 
                    end
                end

                S_MOVE_R: begin
                    if (p2_pulse && led != 8'b0000_0001) begin
                        state <= S_MISS; add_p1 <= 1; 
                    end else if (p2_pulse && led == 8'b0000_0001) begin
                        state <= S_MOVE_L; 
                        
                        // ����ɱ�ж�ʱ�̣���
                        // ����򵽵��ߺ��㰴��ʱ�ļ����� <= 15 (��Ӧ����)��������ɱ��
                        if (speed_cnt <= 8'd15) 
                            smash <= 1'b1;
                        else 
                            smash <= 1'b0;
                            
                        speed_cnt <= 0;
                    end else if (speed_cnt >= current_speed) begin // ʹ�ô���ɱϵͳ���ٶ�
                        speed_cnt <= 0;
                        if (led == 8'b0000_0001) begin
                            state <= S_MISS; add_p1 <= 1; 
                        end else begin
                            led <= {1'b0, led[7:1]}; 
                        end
                    end else begin
                        speed_cnt <= speed_cnt + 1;
                    end
                end

                S_MOVE_L: begin
                    if (p1_pulse && led != 8'b1000_0000) begin
                        state <= S_MISS; add_p2 <= 1; 
                    end else if (p1_pulse && led == 8'b1000_0000) begin
                        state <= S_MOVE_R; 
                        
                        // ����ɱ�ж�ʱ�̣���
                        if (speed_cnt <= 8'd15) 
                            smash <= 1'b1;
                        else 
                            smash <= 1'b0;
                            
                        speed_cnt <= 0;
                    end else if (speed_cnt >= current_speed) begin
                        speed_cnt <= 0;
                        if (led == 8'b1000_0000) begin
                            state <= S_MISS; add_p2 <= 1; 
                        end else begin
                            led <= {led[6:0], 1'b0}; 
                        end
                    end else begin
                        speed_cnt <= speed_cnt + 1;
                    end
                end

                S_MISS: begin
                    beep <= 1; 
                    if (speed_cnt >= 8'd250) begin 
                        state <= S_IDLE; speed_cnt <= 0;
                    end else begin
                        speed_cnt <= speed_cnt + 1;
                    end
                end
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule