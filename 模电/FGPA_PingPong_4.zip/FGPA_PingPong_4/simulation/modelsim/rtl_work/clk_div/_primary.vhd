library verilog;
use verilog.vl_types.all;
entity clk_div is
    port(
        clk_12m         : in     vl_logic;
        rst_n           : in     vl_logic;
        clk_game        : out    vl_logic;
        clk_scan        : out    vl_logic
    );
end clk_div;
