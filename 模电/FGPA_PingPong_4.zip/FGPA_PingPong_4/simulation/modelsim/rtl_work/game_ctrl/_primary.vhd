library verilog;
use verilog.vl_types.all;
entity game_ctrl is
    generic(
        S_IDLE          : integer := 0;
        S_MOVE_R        : integer := 1;
        S_MOVE_L        : integer := 2;
        S_MISS          : integer := 3
    );
    port(
        clk_scan        : in     vl_logic;
        rst_n           : in     vl_logic;
        p1_pulse        : in     vl_logic;
        p2_pulse        : in     vl_logic;
        led             : out    vl_logic_vector(7 downto 0);
        beep            : out    vl_logic;
        add_p1          : out    vl_logic;
        add_p2          : out    vl_logic
    );
end game_ctrl;
