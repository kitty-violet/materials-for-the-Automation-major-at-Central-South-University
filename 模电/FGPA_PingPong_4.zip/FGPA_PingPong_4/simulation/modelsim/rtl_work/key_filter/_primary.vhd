library verilog;
use verilog.vl_types.all;
entity key_filter is
    port(
        clk_scan        : in     vl_logic;
        rst_n           : in     vl_logic;
        key_in          : in     vl_logic;
        key_pulse       : out    vl_logic
    );
end key_filter;
