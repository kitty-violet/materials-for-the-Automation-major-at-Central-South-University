library verilog;
use verilog.vl_types.all;
entity score_counter is
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        add_score       : in     vl_logic;
        tens            : out    vl_logic_vector(3 downto 0);
        ones            : out    vl_logic_vector(3 downto 0)
    );
end score_counter;
