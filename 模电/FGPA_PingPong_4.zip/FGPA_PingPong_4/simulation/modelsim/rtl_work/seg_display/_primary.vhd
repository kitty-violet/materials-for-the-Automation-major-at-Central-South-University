library verilog;
use verilog.vl_types.all;
entity seg_display is
    port(
        clk_scan        : in     vl_logic;
        rst_n           : in     vl_logic;
        p1_tens         : in     vl_logic_vector(3 downto 0);
        p1_ones         : in     vl_logic_vector(3 downto 0);
        p2_tens         : in     vl_logic_vector(3 downto 0);
        p2_ones         : in     vl_logic_vector(3 downto 0);
        seg             : out    vl_logic_vector(7 downto 0);
        sel             : out    vl_logic_vector(7 downto 0)
    );
end seg_display;
