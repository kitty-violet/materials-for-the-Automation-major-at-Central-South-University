library verilog;
use verilog.vl_types.all;
entity tb_tennis is
end tb_tennis;
