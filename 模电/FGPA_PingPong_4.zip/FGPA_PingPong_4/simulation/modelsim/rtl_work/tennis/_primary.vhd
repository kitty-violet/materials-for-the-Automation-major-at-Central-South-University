library verilog;
use verilog.vl_types.all;
entity tennis is
    port(
        clk_12m         : in     vl_logic;
        rst_n           : in     vl_logic;
        key_p1          : in     vl_logic;
        key_p2          : in     vl_logic;
        led             : out    vl_logic_vector(7 downto 0);
        beep            : out    vl_logic;
        seg             : out    vl_logic_vector(7 downto 0);
        sel             : out    vl_logic_vector(7 downto 0)
    );
end tennis;
