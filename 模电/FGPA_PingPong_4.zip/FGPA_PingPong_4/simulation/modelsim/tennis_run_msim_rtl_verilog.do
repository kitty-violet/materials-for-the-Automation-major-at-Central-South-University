transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+E:/modelsim/Code/FGPA_PingPong {E:/modelsim/Code/FGPA_PingPong/clk_div.v}
vlog -vlog01compat -work work +incdir+E:/modelsim/Code/FGPA_PingPong {E:/modelsim/Code/FGPA_PingPong/tennis.v}
vlog -vlog01compat -work work +incdir+E:/modelsim/Code/FGPA_PingPong {E:/modelsim/Code/FGPA_PingPong/key_filter.v}
vlog -vlog01compat -work work +incdir+E:/modelsim/Code/FGPA_PingPong {E:/modelsim/Code/FGPA_PingPong/game_ctrl.v}
vlog -vlog01compat -work work +incdir+E:/modelsim/Code/FGPA_PingPong {E:/modelsim/Code/FGPA_PingPong/score_counter.v}
vlog -vlog01compat -work work +incdir+E:/modelsim/Code/FGPA_PingPong {E:/modelsim/Code/FGPA_PingPong/seg_display.v}

vlog -vlog01compat -work work +incdir+E:/modelsim/Code/FGPA_PingPong {E:/modelsim/Code/FGPA_PingPong/tb_tennis.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cycloneive_ver -L rtl_work -L work -voptargs="+acc" tb_tennis

add wave *
view structure
view signals
run -all
